export default [


    { id: 1, name: 'BWM', price: 110 },
    { id: 2, name: 'Google', price: 10 },
    { id: 3, name: 'Apple', price: 100 },
    { id: 4, name: 'Twitter', price: 20 },
    { id: 5, name: 'Sina', price: 0 },
    { id: 5, name: 'Alibaba', price: 9 }


]