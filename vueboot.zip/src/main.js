import Vue from 'vue'
import App from './App.vue'
import VueRouter from 'vue-router'
import VueResource from 'vue-resource'
Vue.use(VueRouter)
Vue.use(VueResource)

Vue.http.options.root = 'https://vuejs-stock-trader-63848.firebaseio.com/';
import store from './store/store'

import { routes } from './router.config'
Vue.filter('currency', (value) => {
    return '$' + value.toLocaleString()
})
const router = new VueRouter({
    mode: 'history',
    routes
})
new Vue({
    el: '#app',
    store,
    router,
    render: h => h(App)
})