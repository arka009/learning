import Vue from 'vue'
import App from './App.vue'
import Vuetify from 'vuetify'
import VueRouter from 'vue-router'
import '../node_modules/vuetify/dist/vuetify.min.css'
import routerConfig from './router.config.js'
import { store } from './components/store'
Vue.use(VueRouter)
Vue.use(Vuetify)

const router = new VueRouter(routerConfig)
new Vue({
    router,
    store,
    el: '#app',
    render: h => h(App)
})