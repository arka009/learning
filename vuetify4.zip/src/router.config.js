import Home from './components/Home/Home.vue'
import PlayingScreen from './components/PlayingScreen/PlayingScreen.vue'
import Task from './components/Task/Task.vue'
import WorkOrder from './components/WorkOrder/WorkOrder.vue'
import System from './components/System/System.vue'
import Order from './components/Order/Order.vue'
import MyTask from './components/Task/MyTask.vue'

export default {
    routes: [
        { path: '/', component: Home },
        { path: '/Home', component: Home, name: 'home' },
        { path: '/PlayingScreen', component: PlayingScreen, name: 'playingScreen' },
        { path: '/Task', component: Task, name: 'task' },
        { path: '/Task/:id', component: MyTask, name: 'myTask', props: true },
        { path: '/WorkOrder', component: WorkOrder, name: 'workOrder' },
        { path: '/System', component: System, name: 'system' },
        { path: '/Order', component: Order, name: 'order' }
    ]
}