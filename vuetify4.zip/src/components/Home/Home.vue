<template>
    <v-container fluid>
        <v-layout row>
            <v-flex xs6 order-lg2>
                <v-card dark tile flat class="error">
                    <v-card-text>
                        <v-btn large router to="/system" class="info">Explore System</v-btn>
                        <v-btn large router to="/Task" class="info"><v-progress-circular indeterminate v-bind:width="3" class="red--text"></v-progress-circular>
Explore Task</v-btn>
                        <v-bottom-sheet>
                            <v-btn slot="activator" class="purple" dark>Click me</v-btn>
                            <v-list>
                                <v-subheader>Open in</v-subheader>
                                <v-list-tile v-for="item in menuItems" :key="item.title" router :to="item.link">
                                    <v-list-tile-avatar>
                                        <v-avatar size="32px" tile>
                                            <v-icon left>{{item.icon}}</v-icon>
                                        </v-avatar>
                                    </v-list-tile-avatar>
                                    <v-list-tile-title>{{ item.title }}</v-list-tile-title>
                                </v-list-tile>
                            </v-list>
                        </v-bottom-sheet>
                    </v-card-text>

                </v-card>
            </v-flex>
            <v-flex xs6>
                <v-carousel style="cursor:pointer;">
                    <v-carousel-item v-for="meetup in meetups" :src="meetup.imageUrl" :key="meetup.id"  @click="onladMeetup(meetup.id)">

                        <div class="carousel-title transition-box">{{meetup.title}}</div>

                    </v-carousel-item>
                </v-carousel>
            </v-flex>
        </v-layout>

    </v-container>
</template>
<script>
export default {
    data() {
        return {
            meetups: [
                { imageUrl: 'http://g.hiphotos.baidu.com/zhidao/pic/item/3801213fb80e7becc217d04b2c2eb9389a506b4f.jpg', id: '1', title: '我的大刀早已饥渴难耐了' },
                { imageUrl: 'http://pic.58pic.com/58pic/17/53/36/22G58PIC4bZ_1024.jpg', id: '2', title: '我的剑就是你的剑' },
                { imageUrl: 'http://pic.58pic.com/58pic/11/32/66/09g58PICmQM.jpg', id: '3', title: '坚如磐石' }
            ],
            menuItems: [
                { icon: 'home', title: '首页', link: '/home' },
                { icon: 'build', title: '系统管理', link: '/system' },
                { icon: 'store', title: '订单处理', link: '/order' },
                { icon: 'note', title: '360弹屏首页', link: '/playingScreen' },
                { icon: 'chat', title: '任务管理', link: '/task' },
                { icon: 'content_paste', title: '工单管理', link: '/workOrder' }
            ]
        }
    },
    methods: {
        onladMeetup(id){
           
            this.$router.push('/task/'+ id)
        }
    }
}
</script>
<style scoped>
.carousel-title {
    position: absolute;
    bottom: 50px;
    background-color: rgba(0, 0, 0, .5);
    color: #fff;
    font-size: 2em;
    padding: 30px;
}
</style>


