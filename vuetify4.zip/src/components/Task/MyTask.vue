<template>
  <v-container fluid>
    <v-layout row wrap>
      <v-flex xs12>
       <v-card>
         <v-card-title>
           <h6 class="primary--text">{{meetup.title}}</h6>
         </v-card-title>
         <v-card-media :src="meetup.imageUrl" height="400px" contain></v-card-media>
         <v-card-text>
           <div class="info--text">{{meetup.date}} - Where it takes div</div>
         </v-card-text>
         <v-card-actions>
           <v-spacer></v-spacer>
           <v-btn right class="primary">REGISTER</v-btn>
         </v-card-actions>
       </v-card>
      </v-flex>
      
    </v-layout>
    
    
  </v-container>
</template>
<script>
export default {
  props:['id'],
  computed: {
    meetup(){
      return this.$store.getters.loadedMeetup(this.id)
    }
  }
}
</script>
