<template>
  <v-container fluid>
    <v-layout row wrap>
      <v-flex xs12>
       <v-card>
         <v-card-title>
           <h6 class="primary--text">My Task</h6>
         </v-card-title>
         <v-card-media src="http://pic.58pic.com/58pic/12/74/42/34W58PICnqR.jpg" height="400px" contain></v-card-media>
         <v-card-text>
           <div class="info--text">17th July 2017 - Where it takes div</div>
         </v-card-text>
         <v-card-actions>
           <v-spacer></v-spacer>
           <v-btn right class="primary">REGISTER</v-btn>
         </v-card-actions>
       </v-card>
      </v-flex>
      
    </v-layout>
    
    
  </v-container>
</template>
