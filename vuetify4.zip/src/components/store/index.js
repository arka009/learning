import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export const store = new Vuex.Store({
    state: {
        loadedMeetups: [
            { imageUrl: 'http://g.hiphotos.baidu.com/zhidao/pic/item/3801213fb80e7becc217d04b2c2eb9389a506b4f.jpg', id: '1', title: '我的大刀早已饥渴难耐了', date: '2017-07-17' },
            { imageUrl: 'http://pic.58pic.com/58pic/17/53/36/22G58PIC4bZ_1024.jpg', id: '2', title: '我的剑就是你的剑', date: '2017-06-27' },
            { imageUrl: 'http://pic.58pic.com/58pic/11/32/66/09g58PICmQM.jpg', id: '3', title: '坚如磐石', date: '2017-11-11' }
        ],
        user: {
            id: 'ajfdfjkljj12',
            registeredMeetups: ['adjfkdfj3wqoi']
        }
    },
    mutations: {},
    actions: {},
    getters: {
        loadedMeetups(state) {
            return state.loadedMeetups.sort((meetupA, meetupB) => {
                return meetupA.date > meetupB.date
            })
        },
        featuredMeetups(state, getters) {
            return getters.loadedMeetups.slice(0, 5)
        },
        loadedMeetup(state) {
            return (meetupId) => {
                return state.loadedMeetups.find((meetup) => {
                    return meetup.id === meetupId
                })
            }
        }
    }
})