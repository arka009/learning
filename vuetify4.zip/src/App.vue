<template>
  <v-app id="app">
    <v-navigation-drawer
      persistent
      v-model="sideNav"
      light
      enable-resize-watcher
      overflow
    >
      <v-list dense>
        <v-list-tile  v-for="item in menuItems" :key="item.title" router :to="item.link">
          <v-list-tile-action>
            <v-icon>{{item.icon}}</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title>{{item.title}}</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>
      </v-list>
    </v-navigation-drawer>
    <v-toolbar dark class="primary">
      <v-toolbar-side-icon class="hidden-sm-and-up"  @click.native.stop="sideNav =!sideNav"></v-toolbar-side-icon>
      <v-toolbar-title>
        <router-link to="/" tag="span" >DevMeetup</router-link>
      </v-toolbar-title>
      <v-spacer></v-spacer>
      <v-toolbar-items class="hidden-xs-only">
        <v-btn flat v-for="item in menuItems" :key="item.title"  router :to="item.link">
          <v-icon left>{{item.icon}}</v-icon>
          {{item.title}}
          </v-btn>
      </v-toolbar-items>
    </v-toolbar>
    <main>
      <router-view></router-view>
    </main>
  </v-app>
</template>

<script>
export default {
  name: 'app',
  data() {
    return {
     sideNav: false,
     menuItems: [
       { icon: 'home', title: '首页', link: '/home'},
      { icon: 'build', title: '系统管理', link: '/system'},
      { icon: 'store', title: '订单处理', link: '/order'},
      { icon: 'note', title: '360弹屏首页', link: '/playingScreen'},
      { icon: 'chat', title: '任务管理', link: '/task'},
      { icon: 'content_paste', title: '工单管理', link: '/workOrder' }
     ]
    }
  }
}
</script>

<style lang="stylus">
 @import './stylus/main'
</style>
