<template>
  <div class="container">
    <div>
     状态： {{ status }}
    </div>
    <div class="form-inline">
      <input type="text" class="form-control mr-1" v-model="username">
      <button class="btn btn-primary" @click="updateUsername">更新姓名</button>
    </div>
    <table class="table table-striped">
      <thead>
        <tr>
          <th>#</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Username</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(item, i) in listData" :key="i" :class="{'bg-info': item.selected}">
          <th scope="row">{{i+1}}</th>
          <td><img :src="item.picture.medium" width="50"></td>
          <td>{{item.name.first}} {{item.name.last}}</td>
          <td>{{item.email}}</td>
          <td><button class="btn btn-small btn-primary" @click="clickMe(item)">按我</button></td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
<script>
export default {
  props: ['status'],
  data() {
    return {
      listData: [],
      username: ''
    }
  },
  methods: {
    getData() {
      let vm = this;
      vm.axios.get('https://randomuser.me/api/?results=50')
        .then(function(response) {
          console.log(response)
          vm.listData = response.data.results
          vm.listData.forEach((item)=>{
            vm.$set(item, 'selected', false)
          })
        }).catch(function(error) {

        })
    },
    updateUsername(){
      let vm = this;
      vm.$emit('pushNewName', vm.username)
     // console.log(vm.username)
    },
    clickMe(item){
      item.selected = !item.selected
      console.log(item.selected)
    }
  },
  mounted() {
    this.getData()
  }
}
</script>

